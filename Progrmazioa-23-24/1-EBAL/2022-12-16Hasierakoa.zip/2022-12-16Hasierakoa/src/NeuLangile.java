/** Programa honek zure izen abizenak daramatzan erabiltzailea sortuko du, lehenetsitako email eta soldatarekin.
 * Langilearen datuak kontsolatik bistaratu ondoren.
 * Soldata igo eta berriz inprimatuko du langilearen informazioa.
 */
public class NeuLangile {
    public static void main(String[] args) throws Exception {
        //OSATU METODO HAU
    }
}
