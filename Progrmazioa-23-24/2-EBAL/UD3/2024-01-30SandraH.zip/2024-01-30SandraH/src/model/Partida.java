package model;

import java.time.LocalDateTime;

public abstract class Partida {
    protected LocalDateTime noiz;
    protected String t1;
    protected String t2;
    public abstract String getIrabazlea();
}